/* 
 * File:   adc.h
 * Author: laxmi
 *
 * Created on 9 May, 2026, 11:37 AM
 */

#ifndef ADC_H
#define	ADC_H

//read the initialization of adc
void init_adc(void);
//read the adc value
unsigned int read_adc(unsigned char channel);

//define the macros of all channels upto 10
#define CHANNEL0 0
#define CHANNEL1 1
#define CHANNEL2 2
#define CHANNEL3 3
#define CHANNEL4 4
#define CHANNEL5 5
#define CHANNEL6 6
#define CHANNEL7 7
#define CHANNEL8 8
#define CHANNEL9 9
#define CHANNEL10 10

#endif	/* ADC_H */

