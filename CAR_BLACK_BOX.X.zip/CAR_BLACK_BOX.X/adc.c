/*
 * File:   adc.c
 * Author: laxmi
 *
 * Created on 9 May, 2026, 11:45 AM
 */


#include <xc.h>
#include "adc.h"
void init_adc(void)
{
   ADON = 1;//TURN ON THE ADC
   
   
//   PCFG0 = 1;
//   PCFG1 = 0;
//   PCFG2 = 1;
//   PCFG3 = 0;//TO select all channels as analog
   
   VCFG0 = 0;
   VCFG1 = 0;//to select reference voltage 
   
   ADCS0 = 0;
   ADCS1 = 1;
   ADCS2 = 0;//TO select 1TAD = 1.6us
   
   ACQT0 = 0;
   ACQT1 = 1;
   ACQT2 = 0;//TO select 4TAD as acquisition time
   
   ADFM = 1;//TO select right justified
   
 }
unsigned int read_adc(unsigned char channel)
{
   ADCON0=( ADCON0 & 0xC3)|(channel << 2);
   
   GO = 1;
   
   while(GO);
   
   return (ADRESH << 8) | ADRESL;
   
}
