/* 
 * File:   message_handler.h
 * Author: laxmi
 *
 * Created on 9 May, 2026, 12:21 PM
 */

#ifndef MESSAGE_HANDLER_H
#define	MESSAGE_HANDLER_H

void process_car_data(void);
void store_event(void);
void process_dashboard(unsigned char key);
void process_menu_screen(unsigned char key);
void view_log(unsigned char key);
void clear_log(void);
void download_log(unsigned char key);
 void set_time_log(unsigned char key);

#endif	/* MESSAGE_HANDLER_H */

