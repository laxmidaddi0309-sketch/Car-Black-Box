/* 
 * File:   timer0.h
 * Author: laxmi
 *
 * Created on 17 May, 2026, 11:06 PM
 */

#ifndef TIMER0_H
#define	TIMER0_H

void init_timer0();

#endif	/* TIMER0_H */

