/*
 * File:   isr.c
 * Author: laxmi
 *
 * Created on 13 May, 2026, 9:17 PM
 */


#include <xc.h>
#include "timer0.h"
unsigned blink_flag;
void __interrupt() isr(void)
{
    static unsigned int count=0;
    if(TMR0IF == 1)
    {
        TMR0 = TMR0+8;
      if(count++==20000)
      {
          blink_flag=!blink_flag;
          count=0;
      }
      TMR0IF=0;
    }
}
