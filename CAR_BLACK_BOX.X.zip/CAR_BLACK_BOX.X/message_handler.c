/*
 * File:   message_handler.c
 * Author: laxmi
 *
 * Created on 9 May, 2026, 12:22 PM
 */


#include <xc.h>
#include "adc.h"
#include "clcd.h"
#include "ds1307.h"
#include "matrix_keypad.h"
#include "uart.h"
#include "i2c.h"
#include "eeprom.h"
#include "external_eeprom.h"
#include "message_handler.h"
#include "timer0.h"

extern unsigned int previous_speed;
extern unsigned int current_speed;
extern unsigned int prev_gear_pos;
extern unsigned int curr_gear_pos;

extern unsigned int flag;
extern unsigned int menu_pos;
extern unsigned int star_pos;

extern unsigned int blink_flag;

extern unsigned int event_index;
extern unsigned int write_index;
extern unsigned int log_index;

extern unsigned int sec;
extern unsigned int min;
extern unsigned int hour;
extern unsigned int field;

extern unsigned char clock_reg[3];
extern unsigned char calender_reg[4];
extern unsigned char time[9];
extern unsigned char date[11];

char *menu_screen[]={"VIEW_LOG","CLEAR_LOG","DOWNLOAD_LOG","SET_TIME_LOG"};
unsigned char gear[8][3]={"GN","G1","G2","G3","G4","G5","GR","_C"}, menu_enter = 0;
static void get_time(void)
{
	clock_reg[0] = read_ds1307(HOUR_ADDR);
	clock_reg[1] = read_ds1307(MIN_ADDR);
	clock_reg[2] = read_ds1307(SEC_ADDR);

	if (clock_reg[0] & 0x40)
	{
		time[0] = '0' + ((clock_reg[0] >> 4) & 0x01);
		time[1] = '0' + (clock_reg[0] & 0x0F);
	}
	else
	{
		time[0] = '0' + ((clock_reg[0] >> 4) & 0x03);
		time[1] = '0' + (clock_reg[0] & 0x0F);
	}
	time[2] = ':';
	time[3] = '0' + ((clock_reg[1] >> 4) & 0x0F);
	time[4] = '0' + (clock_reg[1] & 0x0F);
	time[5] = ':';
	time[6] = '0' + ((clock_reg[2] >> 4) & 0x0F);
	time[7] = '0' + (clock_reg[2] & 0x0F);
	time[8] = '\0';
}
void display_time(void)
{
	clcd_print(time,LINE2(6));

	if (clock_reg[0] & 0x40)
	{
		if (clock_reg[0] & 0x20)
		{
			clcd_print("PM",LINE2(14));
		}
		else
		{
			clcd_print("AM",LINE2(14));
		}
	}
}

void store_event(void)
{
    unsigned int addr=write_index*12;
    
    //speed
    external_eeprom_write(addr,(current_speed/10)+'0');
    external_eeprom_write(addr+1,(current_speed%10)+'0');
    
     //gear
     external_eeprom_write(addr+2,gear[curr_gear_pos][0]);
     external_eeprom_write(addr+3,gear[curr_gear_pos][1]);
   
      //time
      get_time();
      external_eeprom_write(addr+5,time[1]);
      external_eeprom_write(addr+6,time[2]);
      external_eeprom_write(addr+7,time[3]);
      external_eeprom_write(addr+8,time[4]);
      external_eeprom_write(addr+9,time[5]);
      external_eeprom_write(addr+10,time[6]);
      external_eeprom_write(addr+11,time[7]);
      
      write_index=(write_index+1)%10;
      if(event_index<10)
      {
          event_index++;
      }
      external_eeprom_write(0x7F,event_index);
    
}

void process_dashboard(unsigned char key)
{
    current_speed=read_adc(CHANNEL4);
    current_speed=(current_speed)/10.23;
    
    if(key==SW1)
    {
        curr_gear_pos++;
        if(curr_gear_pos>6)
        {
            curr_gear_pos = 0;
        }
    }
    else if(key==SW2)
    {
        if(curr_gear_pos>0 && curr_gear_pos<6)
        {
             curr_gear_pos--;
        }
    }
    else if(key==SW3)
    {
        curr_gear_pos=0;
    }

    clcd_print("SP",LINE1(0));
    clcd_putch((current_speed/10)+'0',LINE2(0));
    clcd_putch((current_speed%10)+'0',LINE2(1));
    
    clcd_print("EV",LINE1(3));
    clcd_putch(gear[curr_gear_pos][0],LINE2(3));
    clcd_putch(gear[curr_gear_pos][1],LINE2(4));
    
    clcd_print("TIME",LINE1(7));
    get_time();
    display_time();
    
    if(curr_gear_pos!=prev_gear_pos)
    {
        store_event();
        previous_speed=current_speed;
        prev_gear_pos=curr_gear_pos;
    }
}

 void process_menu_screen(unsigned char key)
{
    if(key==SW2)
    {
        if(menu_enter < 3)
        {
            menu_enter++;
        }
        if(star_pos==0)
        {
            star_pos=1;
        }
        else
        {
            if(menu_pos<2)
            {
                menu_pos++;
            }
        }
        CLEAR_DISP_SCREEN;
    }

    if(key==SW1)
    {
        if(menu_enter > 0)
        {
            menu_enter--;
        }
        if(star_pos==1)
        {
            star_pos=0;
        }
        else
        {
            if(menu_pos>0)
            {
                menu_pos--;
            }
        }
        CLEAR_DISP_SCREEN;
    }

    if(menu_pos==3 && star_pos==1)
    {
        star_pos=0;
    }

    if(star_pos==0)
        clcd_putch('*',LINE1(0));
    else
        clcd_putch('*',LINE2(0));

    if(menu_pos == 0)
    {
        clcd_print("VIEW_LOG",LINE1(1));
        clcd_print("CLEAR_LOG",LINE2(1));
    }
    else if(menu_pos==1)
    {
        clcd_print("CLEAR_LOG",LINE1(1));
        clcd_print("DOWNLOAD_LOG",LINE2(1));
    }
    else if(menu_pos==2)
    {
        clcd_print("DOWNLOAD_LOG",LINE1(1));
        clcd_print("SET_TIME_LOG",LINE2(1));
    }
}
 
void view_log(unsigned char key)
{
    //unsigned char key = read_matrix_keypad(EDGE);
    if(event_index==0)
    {
        clcd_print("NO LOGS PRESENT",LINE1(0));
    }
    else
    {
        if(key==SW2)
        {
            if(log_index<(event_index-1))
                log_index++;
        }
        else if(key==SW1)
        {
            if(log_index>0)
                log_index--;
        }

         unsigned int actual_index;

        if(event_index < 10)
        {
            actual_index = log_index;
        }
        else
        {
            actual_index =(write_index + log_index)%10;
        }

        unsigned int addr=actual_index * 12;
        clcd_print("# SP GR TIME",LINE1(0));

        if(log_index == 9)
        {
            clcd_putch('1',LINE2(0));
            clcd_putch('0',LINE2(1));
        }
        else
        {
            clcd_putch((log_index+1)+'0',LINE2(0));
            clcd_putch(' ',LINE2(1));
        }
         //Speed
         clcd_putch(external_eeprom_read(addr), LINE2(2));
         clcd_putch(external_eeprom_read(addr + 1), LINE2(3));
         clcd_putch(' ', LINE2(4));

         //Gear
         clcd_putch(external_eeprom_read(addr + 2), LINE2(5));
         clcd_putch(external_eeprom_read(addr + 3), LINE2(6));
         clcd_putch(' ', LINE2(7));

        //Time
        clcd_putch(external_eeprom_read(addr + 4), LINE2(8));
        clcd_putch(external_eeprom_read(addr + 5), LINE2(9));
        clcd_putch(external_eeprom_read(addr + 6), LINE2(10));
        clcd_putch(external_eeprom_read(addr + 7), LINE2(11));
        clcd_putch(external_eeprom_read(addr + 8), LINE2(12));
        clcd_putch(external_eeprom_read(addr + 9), LINE2(13));
        clcd_putch(external_eeprom_read(addr + 10), LINE2(14));
        clcd_putch(external_eeprom_read(addr + 11), LINE2(15));
    }
}
void clear_log(void)
{
    event_index = 0;
    write_index = 0;
    external_eeprom_write(0x7F,0);
    clcd_print("NO LOGS",LINE1(0));
}
void download_log(unsigned char key)
{
    unsigned int addr;
    unsigned int actual_index;
    static unsigned int once=0;

    puts("IND SPD GR TIME\r\n");
    if(once==0)
    {
        for(unsigned int i=0;i<event_index;i++)
        {
            if(event_index < 10)
            {
                actual_index = i;
            }
            else
                actual_index=(write_index+i)%10;

            addr=actual_index*12;
            if(i==9)
            {
                putch('1');
                putch('0');
            }
            else
            {
                putch((i+1)+'0');
                putch(' ');
            }
            putch(' ');
            //Speed
            putch(external_eeprom_read(addr));
            putch(external_eeprom_read(addr+1));
            putch(' ');

            //gear
            putch(external_eeprom_read(addr+2));
            putch(external_eeprom_read(addr+3));
            putch(' ');

            //time
            putch(external_eeprom_read(addr+4));
            putch(external_eeprom_read(addr+5));
            putch(external_eeprom_read(addr+6));
            putch(external_eeprom_read(addr+7));
            putch(external_eeprom_read(addr+8));
            putch(external_eeprom_read(addr+9));
            putch(external_eeprom_read(addr+10));
            putch(external_eeprom_read(addr+11));
            puts("\r\n");
        }
        once=1;
        clcd_print("DOWNLOADING DONE",LINE1(0));
         return;
    }
        if(menu_enter==2)
        {
            flag=1;
            once=0;
        }

}
 void set_time_log(unsigned char key)
 {
    static unsigned int once=0;
    clcd_print("SET TIME",LINE1(0));

    if(once==0)
    {
        unsigned char h=read_ds1307(HOUR_ADDR);
        unsigned char m=read_ds1307(MIN_ADDR);
        unsigned char s=read_ds1307(SEC_ADDR);
        hour=(((h>>4) & 0x01)*10)+(h & 0x0F);
        min=(((m>>4) & 0x0F)*10)+(m & 0x0F);
        sec=(((s>>4) & 0x0F)*10)+(s & 0x0F);
        once=1;
    }
    
    if(key==SW2)
    {
        field++;
        if(field>2)
        {
            field=0;
        }
    }
    else if(key==SW1)
    {
        if(field==0)
        {
             hour++;
             if(hour>12)
            {
                hour=1;
             }
        }

        else if(field==1)
        {
            min++;
            if(min>=60)
            {
                min=0;
            }
        }
        else if(field==2)
        {
           sec++;
            if(sec>=60)
            {
                sec=0;
            }
        }
    }
    if(blink_flag == 0)
    {
        clcd_putch((hour/10)+'0',LINE2(5));
        clcd_putch((hour%10)+'0',LINE2(6));
        clcd_putch(':',LINE2(7));
        clcd_putch((min/10)+'0',LINE2(8));
        clcd_putch((min%10)+'0',LINE2(9));
        clcd_putch(':',LINE2(10));
        clcd_putch((sec/10)+'0',LINE2(11));
        clcd_putch((sec%10)+'0',LINE2(12));       
    }
    else
    {
        if(field == 0)
        {
            clcd_putch(' ',LINE2(5));
            clcd_putch(' ',LINE2(6));
        }
        else if(field == 1)
        {
            clcd_putch(' ',LINE2(8));
            clcd_putch(' ',LINE2(9));
        }
        else if(field == 2)
        {
            clcd_putch(' ',LINE2(11));
            clcd_putch(' ',LINE2(12));
        }
    }
    
    if(key==SW11)
    {
        write_ds1307(HOUR_ADDR,(((hour/10) << 4)|(hour%10))|0x40);
        write_ds1307(MIN_ADDR,((min/10)<<4)|(min%10));
        write_ds1307(SEC_ADDR,((sec/10)<<4)|(sec%10));
        flag=1;
        once=0;
        CLEAR_DISP_SCREEN;
    }
    else if(key==SW12)
    {
        CLEAR_DISP_SCREEN;
        flag=1;
        once=0;
    }
 }

 void process_car_data(void)
{
    unsigned char key=read_matrix_keypad(EDGE);

    if(flag==0)
    {
        if(key==SW11)
        {
            flag=1;
            CLEAR_DISP_SCREEN;
        }
    }
    else if(flag==1)
    {
        if(key==SW11)
        {
            flag=2;
            key = ALL_RELEASED;
            CLEAR_DISP_SCREEN;
        }
        else if(key==SW12)
        {
            flag=0;
            CLEAR_DISP_SCREEN;
        }
    }
    else
    {
        if(key==SW12 && menu_enter != 3)
        {
            flag=1;
            CLEAR_DISP_SCREEN;
        }
    }

    if(flag==0)
    {
        process_dashboard(key);
    }
    else if(flag==1)
    {
        process_menu_screen(key);
    }
    else if(flag==2)
    {
        if(menu_enter == 0)
        {
            view_log(key);
        }   
        else if(menu_enter == 1)
        {
            clear_log();
        }
        else if(menu_enter == 2)
        {
            download_log(key);
        }
        else if(menu_enter == 3)
        {
            set_time_log(key);
        }
    }
}