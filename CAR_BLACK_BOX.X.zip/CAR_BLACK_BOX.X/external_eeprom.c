/*
 * File:   external_eeprom.c
 * Author: laxmi
 *
 * Created on 17 May, 2026, 8:52 PM
 */


#include <xc.h>
#include "external_eeprom.h"
#include "i2c.h"

#define _XTAL_FREQ 20000000
void external_eeprom_write(unsigned char addr, unsigned char data)
{
    i2c_start();

    i2c_write(0xA0);   
    i2c_write(addr);   
    i2c_write(data);   

    i2c_stop();
    __delay_ms(10);    
}
unsigned char external_eeprom_read(unsigned char addr)
{
    unsigned char data;
    i2c_start();

    i2c_write(0xA0);   
    i2c_write(addr);   

    i2c_rep_start();

    i2c_write(0xA1);   

    data = i2c_read(); 

    i2c_stop();

    return data;
}
