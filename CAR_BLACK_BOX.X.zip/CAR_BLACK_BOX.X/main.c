/*
 * File:   main.c
 * Author: laxmi
 *
 * Created on 9 May, 2026, 11:51 AM
 */


#include <xc.h>
#include "adc.h"
#include "clcd.h"
#include "ds1307.h"
#include "matrix_keypad.h"
#include "uart.h"
#include "i2c.h"
#include "eeprom.h"
#include "external_eeprom.h"
#include "message_handler.h"
#include "timer0.h"
unsigned int previous_speed=0;
unsigned int current_speed=0;
unsigned int prev_gear_pos=0;
unsigned int curr_gear_pos=0;
unsigned int flag=0;
unsigned int menu_pos=0;
unsigned int star_pos=0;

unsigned int event_index=0;
unsigned int write_index=0;
unsigned int log_index=0;

//time
unsigned int sec=0;
unsigned int min=0;
unsigned int hour=0;
unsigned int field=0;

unsigned char clock_reg[3];
unsigned char calender_reg[4];
unsigned char time[9];
unsigned char date[11];

void main(void) {
    init_adc();
    init_clcd();
    init_i2c();
    init_ds1307();
    init_matrix_keypad();
    init_uart();
    init_timer0();
    //event_index=read_internal_eeprom(0x7F);
    event_index=external_eeprom_read(0x7F);
    while(1)
    {
        process_car_data();
    }
    return;
}
