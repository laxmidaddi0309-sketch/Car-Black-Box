/* 
 * File:   external_eeprom.h
 * Author: laxmi
 *
 * Created on 17 May, 2026, 8:52 PM
 */

#ifndef EXTERNAL_EEPROM_H
#define	EXTERNAL_EEPROM_H

#define EEPROM_WRITE     0xA0
#define EEPROM_READ      0xA1

void external_eeprom_write(unsigned char addr, unsigned char data);
unsigned char external_eeprom_read(unsigned char addr);

#endif	/* EXTERNAL_EEPROM_H */

