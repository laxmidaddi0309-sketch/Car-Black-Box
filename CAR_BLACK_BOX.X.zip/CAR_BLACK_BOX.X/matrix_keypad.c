/*
 * File:   matrix_keypad.c
 * Author: laxmi
 *
 * Created on 9 May, 2026, 11:50 AM
 */


#include <xc.h>
#include "matrix_keypad.h"
#define _XTAL_FREQ 20000000
void init_matrix_keypad()
{
    TRISB = (TRISB&0X1F)|0X1E;
//    TRISB5=0;
//    TRISB6=0;
//    TRISB7=0;
//    TRISB1=1;
//    TRISB2=1;
//    TRISB3=1;
//    TRISB4=1;
    RBPU = 0; //To enable pull up on PORTB
}
unsigned char scan_key(void)
{
    ROW0=0;
    ROW1=ROW2=1;
    __delay_us(10);
    if(COL0==0)
    {
        return SW1;
    }
    else if(COL1 == 0)
    {
        return SW4;
    }
    else if(COL2 == 0)
    {
        return SW7;
    }
    else if(COL3 == 0)
    {
        return SW10;
    }
    
    ROW1=0;
    ROW0=ROW2=1;
    __delay_us(10);
    if(COL0==0)
    {
        return SW2;
    }
    else if(COL1 == 0)
    {
        return SW5;
    }
    else if(COL2 == 0)
    {
        return SW8;
    }
    else if(COL3 == 0)
    {
        return SW11;
    }
    
    ROW2=0;
    ROW0=ROW1=1;
    __delay_us(10);
    if(COL0==0)
    {
        return SW3;
    }
    else if(COL1 == 0)
    {
        return SW6;
    }
    else if(COL2 == 0)
    {
        return SW9;
    }
    else if(COL3 == 0)
    {
        return SW12;
    }
    return ALL_RELEASED;
}
unsigned char read_matrix_keypad(unsigned char trigger)
{
    static unsigned int once=1;
    if(trigger == LEVEL)
    {
         return scan_key();
    }
    else if(trigger == EDGE)
    {
        unsigned char key = scan_key();
        if(key!=ALL_RELEASED && once==1)
        {
            once=0;
            return key;
        }
        else if(key==ALL_RELEASED)
        {
            once=1;
        }
        return ALL_RELEASED;
    }
    return ALL_RELEASED;
}
