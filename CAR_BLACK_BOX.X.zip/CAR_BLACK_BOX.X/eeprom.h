/* 
 * File:   eeprom.h
 * Author: laxmi
 *
 * Created on 9 May, 2026, 11:38 AM
 */

#ifndef EEPROM_H
#define	EEPROM_H

void write_internal_eeprom(unsigned char address,unsigned char data);
unsigned char read_internal_eeprom(unsigned char address);

#endif	/* EEPROM_H */

