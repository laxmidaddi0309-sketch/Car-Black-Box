/* 
 * File:   matrix_keypad.h
 * Author: laxmi
 *
 * Created on 9 May, 2026, 11:38 AM
 */

#ifndef MATRIX_KEYPAD_H
#define	MATRIX_KEYPAD_H

void init_matrix_keypad(void);
unsigned char read_matrix_keypad(unsigned char trigger);
unsigned char scan_key(void);

//this is used for continuous press the key
#define LEVEL 1
//this is used for only one type press the key
#define EDGE  0

//macros of all matrix keypad switches
#define SW1    1
#define SW2    2
#define SW3    3
#define SW4    4
#define SW5    5
#define SW6    6
#define SW7    7
#define SW8    8
#define SW9    9
#define SW10   10
#define SW11   11
#define SW12   12
//no key is pressed
#define ALL_RELEASED  0xFF

//row pin initialization
#define ROW0     RB5
#define ROW1     RB6
#define ROW2     RB7

//coloumn pin initialization
#define COL0     RB1
#define COL1     RB2
#define COL2     RB3
#define COL3     RB4



#endif	/* MATRIX_KEYPAD_H */

